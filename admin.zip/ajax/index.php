<?php
header("Location: /");
?>