<?php
require("TMQ/function.php");
require("TMQ/head.php");
?>
 <link href='https://fonts.googleapis.com/css?family=Roboto+Condensed:300italic,400italic,700italic,400,300,700&amp;subset=all' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="/assets/frontend/css/site.css">
      <link rel="stylesheet" type="text/css" href="/assets/frontend/css/responsive.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <br /> <br />
<div class="c-layout-page">
    <!-- BEGIN: PAGE CONTENT -->
 
<div class="c-content-title-1 pd50">
    <h3 class="c-center c-font-uppercase c-font-bold">Vòng quay</h3>
    <div class="c-line-center c-theme-bg"></div>
</div>
  <div class="container"><div class="content">

	<div class="contentquay contentquaysingle">

		<div class="row">
			<div class="col-xs-12">
				<div class="box_quay">

			
	
					<div class="turntable-bg">
						<div class="icon_kim"></div>
				        <div id="pointer10" class="pointer"></div>
				        <div class="rotate" ><img id="rotate" src="/vongquay/vong10k.png" alt="turntable"/></div>

					</div>
					<div class="boxwh">
					 <div class="boxwhite">
					 	<div class="giatien">Lượt quay <b>20,000 VNĐ</b></div>
					 	
					 	
					</div>
					
					</div>

				

				</div>
			</div>
		</div>
	</div>
</div>

<div style="display: none;">

<div id="res">
<div class="box_popup">
	<div class="content_popup">
		
		<div id="kq10" class="result"><span></span></div>
		<div id="quaydone"><div class="q"></div></div>

	</div>
</div>

</div>
<!-- END: PAGE CONTAINER -->
<a name="footer"></a>
	</div></div>
	</div></div>
	</div>


<script type="text/javascript" src="/assets/lib/jquery-2.1.1.min.js"></script>    
<script type="text/javascript" src="/assets/lib/magnific/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="/assets/lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/assets/frontend/js/main.js"></script>

<?php require("TMQ/end.php"); ?>
